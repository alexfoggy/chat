<div class="row">
    <div class="col-2">
        <h2 class="mb-3"><b>{{ $title }}</b></h2>
    </div>
    <div class="col">
        <nav class="tabs">
            <button class="active"><span>20</span>New</button>
            <button>Claimed</button>
            <button><span>5</span>In Progress</button>
            <button>Delivered</button>
            <button>Checked</button>
            <button>Approved</button>
            <button>Ready to Invoice</button>
            <button>Invoiced</button>
            <button>All</button>
        </nav>
    </div>
</div>
