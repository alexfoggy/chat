<h2>Hello dear {{$user->first_name}} {{$user->last_name}}</h2>
<p>It seams that you forget about your task from Unicrowd.</p>
<p>please finish you task till {time} </p>
<br>
<p>unicrowd team</p>
