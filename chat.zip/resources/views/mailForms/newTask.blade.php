<div style="'"></div>
<h2>Hello dear,{{$user->first_name}}</h2>

