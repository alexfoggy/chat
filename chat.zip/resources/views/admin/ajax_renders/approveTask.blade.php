<div class="modal-content bd-0 mt-5 w-25">
    <div class="modal-header pd-x-20">
        <h6 class="tx-14 mg-b-0 tx-uppercase tx-inverse tx-bold">Send task</h6>

    </div>
    <div class="modal-body pd-20">
        <p class="mg-b-5">You have finished task, please give us know about that.</p>
        <p>When you upload audio or record audio you should send it by pressing button "Send fot
            verification".</p>
        <p class="tx-danger">After verification you will recive email with your status.</p>
    </div>
    <div class="modal-footer justify-content-center">
        <button type="button" class="btn btn-success sendVerify">Send for verification</button>
    </div>
</div>
