<?php $__currentLoopData = $responseMsg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oneMsg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($oneMsg->userStatus == 2): ?>
        <div class="left-q">
            <div class="small-image-assist">
                <img src="" alt="">
            </div>
            <div class="msg-block">
                <div class="msg-text">
                    <?php echo e($oneMsg->msg); ?>

                </div>
                <div class="date-msg">
                    <?php echo e(\Illuminate\Support\Carbon::parse($oneMsg->created_at)->format('H:m')); ?>

                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="right-q">
            <div class="small-image-assist">
                <img src="" alt="">
            </div>
            <div class="msg-block">
                <div class="msg-text">
                    <?php echo e($oneMsg->msg); ?>

                </div>
                <div class="date-msg">
                    <?php echo e(\Illuminate\Support\Carbon::parse($oneMsg->created_at)->format('h:m')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\OSPanel\domains\chat\resources\views/messages/historyMsg.blade.php ENDPATH**/ ?>