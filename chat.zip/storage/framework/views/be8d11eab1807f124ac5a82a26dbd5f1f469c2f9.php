<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldPushContent('title'); ?></title>
    <link href="<?php echo e(asset('assets/css/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/perfect-scrollbar/css/perfect-scrollbar.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/SpinKit/css/spinkit.css')); ?>" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('images/fav.png')); ?>">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php echo $__env->yieldPushContent('styles'); ?>
<!-- Slim CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slim.css')); ?>">

</head>
<body>
<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('assets/js/jquery/js/jquery.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/scripts.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/popper.js/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.cookie/js/jquery.cookie.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/perfect-scrollbar/js/perfect-scrollbar.jquery.min.js')); ?>"></script>

<?php echo $__env->yieldPushContent('scripts'); ?>

<script src="<?php echo e(asset('assets/js/slim.js?v='.\Carbon\Carbon::now()->getTimestamp())); ?>"></script>

</body>
</html>
<?php /**PATH E:\OSPanel\domains\chat\resources\views/layouts/no-header.blade.php ENDPATH**/ ?>