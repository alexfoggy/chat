<div class="right-q">
    <div class="small-image-assist">
        <img src="" alt="">
    </div>
    <div class="msg-block">
        <div class="msg-text">
            <?php echo e($newMsg->msg); ?>

        </div>
        <div class="date-msg">
            <?php echo e(\Illuminate\Support\Carbon::parse($newMsg->created_at)->format('H:m')); ?>

        </div>
    </div>
</div>
<?php /**PATH E:\OSPanel\domains\chat\resources\views/messages/userMsg.blade.php ENDPATH**/ ?>