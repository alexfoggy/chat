<?php

return [
    'python' => [
        'interpreter' => 'python'
    ]
];
