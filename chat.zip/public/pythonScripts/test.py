#!/bin/python
print ('Content-type: text/html')
print ('Python is working fine on your server')
